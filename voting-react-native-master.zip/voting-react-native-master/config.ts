import _VOTING_ABI from './src/blockchain/abi/Voting.json';

export const VOTING_ABI = _VOTING_ABI;
export const VOTING_ABI_ADDRESS = '0x14851ed2089f3ca46e42195a345d024ebae48c27';

export const RPC_URL = 'https://data-seed-prebsc-1-s2.binance.org:8545';
export const BASE_URL = 'http://3.1.112.25:4444';
