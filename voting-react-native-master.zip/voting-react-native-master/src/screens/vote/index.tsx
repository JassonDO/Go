import {useNavigation} from '@react-navigation/native';
import dayjs from 'dayjs';
import {get} from 'lodash';
import {observer, useLocalObservable} from 'mobx-react-lite';
import {
  Badge,
  Box,
  FlatList,
  HStack,
  Pressable,
  Spinner,
  Text,
  View,
  VStack,
} from 'native-base';
import React, {useEffect} from 'react';
import {Vote} from '../../common/type';
import ButtonLogin from '../../components/button-login';
import {useGlobalStore} from '../../stores';
import VoteStore from '../../stores/vote';
const VoteScreen = observer(() => {
  const {authStore} = useGlobalStore();

  const voteStore = useLocalObservable(() => new VoteStore());

  useEffect(() => {
    if (authStore.isLoggedIn) {
      voteStore.fetchVotes(authStore.address);
    }
  }, [authStore.address, authStore.isLoggedIn]);

  return (
    <View bgColor="white" height={'100%'} px={3} position="relative">
      <>
        {!authStore.isLoggedIn ? (
          <VStack>
            <ButtonLogin />
            <Text fontSize={16} fontWeight={600} textAlign="center">
              Please login to see your vote history
            </Text>
          </VStack>
        ) : voteStore.loading.fetchVotes ? (
          <Box
            alignItems={'center'}
            top="50%"
            height="100%"
            style={{
              transform: [{translateY: -50}],
            }}>
            <Spinner size="lg" />
          </Box>
        ) : get(voteStore, 'votes.length') <= 0 ? (
          <Text fontSize={16} fontWeight={600} textAlign="center">
            You have not voted yet
          </Text>
        ) : (
          <FlatList
            mt={2}
            data={voteStore.votes}
            renderItem={({item}) => <VoteItem vote={item} />}
            keyExtractor={item => item._id}
          />
        )}
      </>
    </View>
  );
});

const VoteItem = observer(({vote}: {vote: Vote}) => {
  const navigation = useNavigation<any>();
  const {name, pool, timestamp} = vote;
  return (
    <Pressable
      onPress={() => {
        navigation.navigate('PoolDetail', {poolId: pool.pool_id});
      }}>
      <VStack
        px={3}
        py={2}
        justifyContent="flex-start"
        borderRadius={2}
        bgColor="rgba(11, 135, 147,0.1)"
        my={1}>
        <HStack display="flex">
          <HStack space={1} flexGrow={1}>
            <Text fontSize={16} fontWeight={600}>
              {pool.name}
            </Text>
            <Text fontSize={16} fontWeight={500} color="gray.500">
              {`#${pool.pool_id}`}
            </Text>
          </HStack>

          <Text fontSize={14} fontWeight={500} color="gray.600">
            {`${dayjs(timestamp * 1000).format('DD/MM/YYYY HH:mm')}`}
          </Text>
        </HStack>

        <HStack space={1}>
          <Text fontSize={14} fontWeight={500} color="gray.600">
            {`Candidate:`}
          </Text>

          <Text fontSize={14} fontWeight={700} color="gray.600">
            {`${name}`}
          </Text>
        </HStack>

        <HStack justifyContent={'space-between'} alignItems="center">
          <Text fontSize={14} fontWeight={500} color="gray.600">
            {`Close: ${dayjs(pool.closed_at * 1000).format(
              'DD/MM/YYYY HH:mm',
            )}`}
          </Text>

          <Badge
            variant="solid"
            colorScheme={pool.closed_at > Date.now() / 1000 ? 'info' : 'red'}>
            {pool.closed_at > Date.now() / 1000 ? 'Open' : 'Closed'}
          </Badge>
        </HStack>
      </VStack>
    </Pressable>
  );
});

export default VoteScreen;
