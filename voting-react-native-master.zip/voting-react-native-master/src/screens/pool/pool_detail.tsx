import {RouteProp, useNavigation, useRoute} from '@react-navigation/native';
import {BigNumber} from 'ethers';
import {observer, useLocalObservable} from 'mobx-react-lite';
import {
  Box,
  Divider,
  HStack,
  Pressable,
  Progress,
  Spinner,
  Text,
  useToast,
  VStack,
} from 'native-base';
import React, {useEffect} from 'react';
import PoolStore from '../../stores/pool';

import Icon from 'react-native-vector-icons/Ionicons';
import {useGlobalStore} from '../../stores';
import dayjs from 'dayjs';
import Common from '../../common/common';

type ParamList = {
  PoolDetail: {
    poolId: BigNumber;
  };
};

const PoolDetail = observer(() => {
  const {poolId} = useRoute<RouteProp<ParamList, 'PoolDetail'>>().params;
  const {authStore} = useGlobalStore();
  const toast = useToast();

  const poolStore = useLocalObservable(() => new PoolStore());
  const navigation = useNavigation();
  useEffect(() => {
    poolStore.getPool(poolId);
  }, [poolId]);

  useEffect(() => {
    if (authStore.isLoggedIn) {
      poolStore.getIsVoted(poolId, authStore.address);
    }
  }, [poolId, authStore.isLoggedIn]);

  useEffect(() => {
    if (poolStore.pool) {
      navigation.setOptions({title: poolStore.pool.name});
    }
  });

  const {pool} = poolStore;

  const vote = async (candidateId: BigNumber) => {
    if (!authStore.isLoggedIn || poolStore.isVoted) {
      return;
    }

    if (!pool) {
      return;
    }

    await poolStore.vote(pool.id, candidateId);

    await toast.show({
      title: 'Vote successfully',
      placement: 'top',
      duration: 3000,
      backgroundColor: 'success.500',
    });
    await Promise.all([
      poolStore.getPool(poolId),
      poolStore.getIsVoted(poolId, authStore.address),
    ]);
  };

  return (
    <VStack bgColor="white" minH={'100%'}>
      {poolStore.loading.getPool ? (
        <Box
          alignItems={'center'}
          top="50%"
          height="100%"
          style={{
            transform: [{translateY: -50}],
          }}>
          <Spinner size="lg" />
        </Box>
      ) : !pool ? (
        <Text>Pool not found</Text>
      ) : (
        <VStack p={2} space={3}>
          {poolStore.loading.vote ? (
            <Box p={3} bgColor="gray.200">
              <Spinner size="sm" />
            </Box>
          ) : (
            <>
              <Box>
                {poolStore.isClosed() ? (
                  <VStack space={2}>
                    <Box p={3} bgColor="error.500">
                      <Text color="white" fontWeight={700} fontSize={16}>
                        Pool is closed
                      </Text>
                    </Box>

                    {poolStore.winners.length === 0 ? (
                      <Box p={3} bgColor="gray.500">
                        <Text color="white" fontWeight={700} fontSize={16}>
                          No winner
                        </Text>
                      </Box>
                    ) : poolStore.winners.length === 1 ? (
                      <Box p={3} bgColor="success.400">
                        <Text color="white" fontWeight={700} fontSize={16}>
                          Winner: {poolStore.winners[0].name}
                        </Text>
                      </Box>
                    ) : (
                      <Box p={3} bgColor="info.400">
                        <Text color="white" fontWeight={700} fontSize={16}>
                          Have {poolStore.winners.length} candidates have equal
                          votes:
                        </Text>

                        {poolStore.winners.map((winner, index) => {
                          return (
                            <Text key={index} color="white" fontWeight={700}>
                              - {winner.name}: {winner.vote_count.toString()}
                            </Text>
                          );
                        })}
                      </Box>
                    )}
                  </VStack>
                ) : !authStore.isLoggedIn ? (
                  <Pressable
                    p={3}
                    bgColor="error.400"
                    onPress={authStore.connectWallet}>
                    <Text color="white" fontWeight={700} fontSize={16}>
                      You need to login to vote
                    </Text>
                  </Pressable>
                ) : poolStore.isVoted ? (
                  <Box p={3} bgColor="success.400">
                    <Text color="white" fontWeight={700} fontSize={16}>
                      You have voted for {poolStore.candidate || 'Unknown'}
                    </Text>
                  </Box>
                ) : (
                  <Box p={3} bgColor="gray.400">
                    <Text color="white" fontWeight={700} fontSize={16}>
                      Please choose your favorite candidate and vote for them.
                      You can only vote once.
                    </Text>
                  </Box>
                )}
              </Box>
            </>
          )}

          <VStack
            p={3}
            space={3}
            bgColor="rgba(0, 0, 0,0.2)"
            borderRadius={2}
            divider={<Divider />}>
            {pool.candidates.map((candidate, index) => {
              const percentage =
                pool.totalVotes.toNumber() > 0
                  ? (
                      (candidate.votes.toNumber() /
                        pool.totalVotes.toNumber()) *
                      100
                    ).toFixed(2)
                  : 0;

              return (
                <Pressable
                  key={index}
                  onPress={() => {
                    vote(candidate.id);
                  }}>
                  <HStack space={2} alignItems="center" display={'flex'}>
                    <HStack alignItems="flex-end" flexGrow={1}>
                      <Text fontSize={16} fontWeight={500}>
                        {candidate.name}
                      </Text>
                      {authStore.isAdmin() && (
                        <HStack alignItems="flex-end">
                          <Icon
                            name="caret-up-outline"
                            size={20}
                            color="green"
                          />
                          <Text
                            fontSize={16}
                            fontWeight={500}
                            color={'green.700'}>
                            {candidate.votes.toString()}
                          </Text>
                        </HStack>
                      )}
                    </HStack>
                  </HStack>

                  {authStore.isAdmin() && (
                    <HStack
                      width={'100%'}
                      alignItems="center"
                      justifyContent={'space-between'}>
                      <Progress value={+percentage} flexGrow={1} />

                      <Box width={70}>
                        <Text textAlign="right">{percentage}%</Text>
                      </Box>
                    </HStack>
                  )}
                </Pressable>
              );
            })}
          </VStack>

          <Box p={3} bgColor="rgba(0, 0, 0,0.1)" borderRadius={2}>
            <Text fontSize={16} fontWeight={500}>
              About:
            </Text>
            <Text>{pool.description}</Text>
          </Box>

          <VStack space={1} p={3} bgColor="rgba(0, 0, 0,0.1)" borderRadius={2}>
            <HStack justifyContent="space-between">
              <Text>Created by:</Text>
              <Text> {Common.shortenAddress(pool.createdBy)}</Text>
            </HStack>

            <HStack justifyContent="space-between">
              <Text>Created at:</Text>
              <Text>
                {dayjs(pool.createdAt.toNumber() * 1000).format(
                  'DD/MM/YYYY HH:mm',
                )}
              </Text>
            </HStack>

            <HStack justifyContent="space-between">
              <Text>Closed at:</Text>
              <Text>
                {dayjs(pool.closedAt.toNumber() * 1000).format(
                  'DD/MM/YYYY HH:mm',
                )}
              </Text>
            </HStack>

            <HStack justifyContent="space-between">
              <Text>Total votes:</Text>
              <Text>{pool.totalVotes.toString()}</Text>
            </HStack>
          </VStack>
        </VStack>
      )}
    </VStack>
  );
});

export default PoolDetail;
