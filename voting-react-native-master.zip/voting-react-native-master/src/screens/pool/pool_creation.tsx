import {
  DateTimePickerAndroid,
  DateTimePickerEvent,
} from '@react-native-community/datetimepicker';
import {useNavigation} from '@react-navigation/native';
import dayjs from 'dayjs';
import {observer, useLocalObservable} from 'mobx-react-lite';
import {
  Button,
  FormControl,
  HStack,
  IconButton,
  Input,
  ScrollView,
  Text,
  VStack,
  useToast,
} from 'native-base';
import React, {useState} from 'react';
import Icon from 'react-native-vector-icons/Ionicons';
import {AndroidMode, PoolCreationData} from '../../common/type';
import PoolStore from '../../stores/pool';

const PoolCreation = observer(() => {
  const [formData, setData] = React.useState<PoolCreationData>({
    name: '',
    description: '',
    candidates: [],
    endTime: new Date(),
  });

  const toast = useToast();

  const [tempCandidate, setTempCandidate] = useState<string>('');

  const onChange = (event: DateTimePickerEvent, selectedDate?: Date) => {
    const currentDate = selectedDate;
    if (currentDate) {
      setData({
        ...formData,
        endTime: currentDate,
      });
    }
  };

  const showMode = (currentMode: AndroidMode | undefined) => {
    DateTimePickerAndroid.open({
      value: formData.endTime,
      onChange,
      mode: currentMode,
      is24Hour: true,
    });
  };

  const showDatepicker = () => {
    showMode('date');
  };

  const showTimepicker = () => {
    showMode('time');
  };

  const addCandidate = () => {
    if (!tempCandidate) {
      return;
    }

    setData({
      ...formData,
      candidates: [...(formData.candidates || []), tempCandidate],
    });
    setTempCandidate('');
  };

  const poolStore = useLocalObservable(() => new PoolStore());
  const navigation = useNavigation<any>();
  const createPool = async () => {
    await poolStore.createPool(formData);
    await toast.show({
      title: 'Create successfully',
      placement: 'top',
      duration: 3000,
      backgroundColor: 'success.500',
    });
    navigation.replace('Home');
  };

  return (
    <ScrollView p={3} bgColor="white">
      <VStack space={2}>
        <FormControl isRequired>
          <FormControl.Label
            _text={{
              bold: true,
            }}>
            Name
          </FormControl.Label>
          <Input
            _focus={{
              bgColor: 'primary.50',
            }}
            placeholder="Name here..."
            onChangeText={value => setData({...formData, name: value})}
          />
        </FormControl>

        <FormControl isRequired>
          <FormControl.Label
            _text={{
              bold: true,
            }}>
            Description
          </FormControl.Label>
          <Input
            _focus={{
              bgColor: 'primary.50',
            }}
            placeholder="Description here..."
            onChangeText={value => setData({...formData, description: value})}
          />
        </FormControl>

        <FormControl isRequired>
          <FormControl.Label
            _text={{
              bold: true,
            }}>
            Cadidates
          </FormControl.Label>
          <Input
            onSubmitEditing={() => {
              addCandidate();
            }}
            _focus={{
              bgColor: 'primary.50',
            }}
            placeholder="Cadidates here..."
            value={tempCandidate}
            onChangeText={value => setTempCandidate(value)}
            InputRightElement={
              <IconButton
                icon={
                  <Icon
                    name="add"
                    size={20}
                    onPress={() => {
                      addCandidate();
                    }}
                  />
                }
              />
            }
          />

          {formData.candidates.map((candidate, index) => {
            return (
              <HStack alignItems={'center'} key={index} px={1}>
                <Text>{candidate}</Text>
                <IconButton
                  icon={
                    <Icon
                      name="trash"
                      color={'red'}
                      size={20}
                      onPress={() => {
                        setData({
                          ...formData,
                          candidates: formData.candidates.filter(
                            (c, i) => i !== index,
                          ),
                        });
                      }}
                    />
                  }
                />
              </HStack>
            );
          })}
        </FormControl>

        <FormControl isRequired>
          <FormControl.Label
            _text={{
              bold: true,
            }}>
            Closed time
          </FormControl.Label>
          <HStack space={2}>
            <Button
              variant={'outline'}
              onPress={() => {
                showDatepicker();
              }}
              flexGrow={3}
              endIcon={<Icon name="calendar" size={20} />}>
              <Text>{dayjs(formData.endTime).format('DD/MM/YYYY')}</Text>
            </Button>

            <Button
              variant={'outline'}
              onPress={() => {
                showTimepicker();
              }}
              flexGrow={1}
              endIcon={<Icon name="time" size={20} />}>
              <Text> {dayjs(formData.endTime).format('HH:mm')}</Text>
            </Button>
          </HStack>
        </FormControl>

        <FormControl mt={5}>
          <Button
            isLoading={poolStore.loading.createPool}
            onPress={() => {
              createPool();
            }}
            colorScheme="success"
            variant="solid">
            <Text color="white" fontSize={18} fontWeight="700">
              CREATE
            </Text>
          </Button>
        </FormControl>
      </VStack>
    </ScrollView>
  );
});

export default PoolCreation;
