import {useNavigation} from '@react-navigation/native';
import {observer} from 'mobx-react-lite';
import {
  Button,
  FormControl,
  HStack,
  Input,
  Text,
  useToast,
  View,
  VStack,
} from 'native-base';
import React from 'react';
import {useGlobalStore} from '../../stores';

interface IUpdateAccount {
  name: string;
  email: string;
}
const AccountUpdate = observer(() => {
  const {authStore} = useGlobalStore();
  const toast = useToast();

  const navigation = useNavigation<any>();

  const navigateToAccountDetail = () => {
    navigation.navigate('AccountDetail');
  };

  const [formData, setData] = React.useState<IUpdateAccount>({
    name: authStore.user.name,
    email: authStore.user.email,
  });

  const updateAccount = async () => {
    console.log({formData});
    await authStore.updateUser(formData);

    await toast.show({
      title: 'Update successfully',
      placement: 'top',
      duration: 3000,
      backgroundColor: 'success.500',
    });
    navigateToAccountDetail();
  };
  return (
    <View bgColor="white" height={'100%'} px={3} position="relative">
      <VStack py={2} height={'100%'}>
        <VStack flexGrow={1} space={5} display="flex" alignItems={'center'}>
          <VStack space={3} w="100%">
            <FormControl isRequired>
              <FormControl.Label
                _text={{
                  bold: true,
                }}>
                Name
              </FormControl.Label>
              <Input
                _focus={{
                  bgColor: 'primary.50',
                }}
                value={formData.name}
                placeholder="Name here..."
                onChangeText={value => setData({...formData, name: value})}
              />
            </FormControl>

            <FormControl isRequired>
              <FormControl.Label
                _text={{
                  bold: true,
                }}>
                Email
              </FormControl.Label>
              <Input
                _focus={{
                  bgColor: 'primary.50',
                }}
                value={formData.email}
                placeholder="Email here..."
                onChangeText={value => setData({...formData, email: value})}
              />
            </FormControl>
          </VStack>
        </VStack>

        <HStack w="100%" space={3}>
          <Button
            colorScheme="success"
            flexGrow={1}
            onPress={updateAccount}
            isLoading={authStore.loading.updateUser}>
            <Text fontWeight={700} fontSize={18} color="white">
              SAVE
            </Text>
          </Button>

          <Button
            colorScheme="muted"
            flexGrow={1}
            onPress={navigateToAccountDetail}>
            <Text fontWeight={700} fontSize={18} color="white">
              CANCEL
            </Text>
          </Button>
        </HStack>
      </VStack>
    </View>
  );
});

export default AccountUpdate;
