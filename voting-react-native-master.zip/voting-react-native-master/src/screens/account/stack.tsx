import {createNativeStackNavigator} from '@react-navigation/native-stack';
import React from 'react';
import AccountDetail from './account-detail';
import AccountUpdate from './account-update';

const Stack = createNativeStackNavigator();

const AccountStack = () => {
  return (
    <Stack.Navigator
      screenOptions={{
        headerShown: false,
      }}>
      <Stack.Screen name="AccountDetail" component={AccountDetail} />

      <Stack.Screen name="AccountUpdate" component={AccountUpdate} />
    </Stack.Navigator>
  );
};

export default AccountStack;
