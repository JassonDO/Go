import {useNavigation} from '@react-navigation/native';
import {observer} from 'mobx-react-lite';
import {Avatar, Button, HStack, Text, View, VStack} from 'native-base';
import React from 'react';
import Common from '../../common/common';
import ButtonLogin from '../../components/button-login';
import {useGlobalStore} from '../../stores';
const AccountDetail = observer(() => {
  const {authStore} = useGlobalStore();

  const navigation = useNavigation<any>();

  const navigateToUpdateAccount = () => {
    navigation.navigate('AccountUpdate');
  };

  const logout = () => {
    authStore.logout();
    navigation.navigate('Home');
  };

  return (
    <View bgColor="white" height={'100%'} px={3} position="relative">
      {!authStore.isLoggedIn ? (
        <VStack>
          <ButtonLogin />
          <Text fontSize={16} fontWeight={600} textAlign="center">
            Please login to see your account information
          </Text>
        </VStack>
      ) : (
        <VStack py={2} height={'100%'}>
          <VStack flexGrow={1} space={5} display="flex" alignItems={'center'}>
            <Avatar source={require('../../assets/avatar.png')} size={200} />
            <VStack space={1}>
              <InfoField
                label="Address"
                value={Common.shortenAddress(authStore.address)}
              />
              <InfoField label="Name" value={authStore.user.name} />
              <InfoField label="Email" value={authStore.user.email} />
              <InfoField label="Role" value={authStore.getRoleName() || ''} />
            </VStack>
          </VStack>
          <VStack space={2}>
            <Button
              w="100%"
              bgColor={'#7E59EC'}
              onPress={navigateToUpdateAccount}>
              <Text fontWeight={700} fontSize={18} color="white">
                UPDATE INFORMATION
              </Text>
            </Button>

            <Button w="100%" bgColor="gray.500" onPress={logout}>
              <Text fontWeight={700} fontSize={18} color="white">
                LOGOUT
              </Text>
            </Button>
          </VStack>
        </VStack>
      )}
    </View>
  );
});

const InfoField = ({label, value}: {label: string; value: string}) => {
  return (
    <HStack space={2}>
      <Text fontSize={18} w="80px">
        {label}:
      </Text>
      <Text fontSize={18} fontWeight={600} textAlign="right">
        {value}
      </Text>
    </HStack>
  );
};

export default AccountDetail;
