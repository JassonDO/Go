import {View, Text} from 'native-base';
import React from 'react';

const PermissionScreen = () => {
  return (
    <View bgColor="white" height={'100%'} px={3} position="relative">
      <Text>PermissionScreen</Text>
    </View>
  );
};

export default PermissionScreen;
