import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {Box} from 'native-base';
import React from 'react';
import HomeScreen from '.';
import PoolCreation from '../pool/pool_creation';
import PoolDetail from '../pool/pool_detail';

const Stack = createNativeStackNavigator();

const HomeStack = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen
        name="Home"
        component={HomeScreen}
        options={{
          headerShown: false,
        }}
      />

      <Stack.Screen
        name="PoolCreation"
        component={PoolCreation}
        options={{
          title: 'Create Pool',
          headerBackTitle: 'Back',
          headerBackground: () => <Box flex={1} bgColor="white" />,
        }}
      />

      <Stack.Screen
        name="PoolDetail"
        component={PoolDetail}
        options={{
          title: '',
          headerBackTitle: 'Back',
          headerBackground: () => <Box flex={1} bgColor="white" />,
        }}
      />
    </Stack.Navigator>
  );
};

export default HomeStack;
