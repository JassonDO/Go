import {BigNumber} from 'ethers';
import {observer, useLocalObservable} from 'mobx-react-lite';
import {
  Avatar,
  Badge,
  Box,
  Fab,
  FlatList,
  HStack,
  Spinner,
  Text,
  View,
  VStack,
} from 'native-base';
import React, {useEffect} from 'react';
import {Pressable} from 'react-native';
import Common from '../../common/common';

import {useIsFocused, useNavigation} from '@react-navigation/native';
import dayjs from 'dayjs';
import Icon from 'react-native-vector-icons/Ionicons';
import ButtonLogin from '../../components/button-login';
import {useGlobalStore} from '../../stores';
import PoolStore from '../../stores/pool';

const HomeScreen = observer(() => {
  const {authStore} = useGlobalStore();

  const navigation = useNavigation<any>();

  const goToCreatePool = () => {
    navigation.navigate('PoolCreation');
  };

  return (
    <View bgColor="white" height={'100%'} px={3} position="relative">
      <UserInfo />
      <ListPool />

      {(authStore.isAdmin() || authStore.isModerator()) && (
        <Fab
          renderInPortal={false}
          onPress={goToCreatePool}
          position="absolute"
          size="sm"
          bgColor={'#7E59EC'}
          icon={<Icon color="white" name="add" size={20} />}
        />
      )}
    </View>
  );
});

const UserInfo = observer(() => {
  const {authStore} = useGlobalStore();
  const navigation = useNavigation<any>();

  const navigateToAccount = () => {
    navigation.navigate('AccountScreen');
  };

  return (
    <Box>
      {authStore.isLoggedIn ? (
        <Pressable onPress={navigateToAccount}>
          <HStack
            px={3}
            py={2}
            space={2}
            bgColor="rgba(126, 89, 236,0.2)"
            alignItems="center"
            borderRadius={2}>
            <Avatar source={require('../../assets/avatar.png')} size={60} />
            <VStack>
              <HStack alignItems="center" space={2}>
                <Text fontSize={18} fontWeight={500}>
                  {Common.shortenAddress(authStore.address)}
                </Text>
                {authStore.loading.getRole ? (
                  <Spinner size="sm" />
                ) : (
                  <Text fontSize={12} fontWeight={700}>
                    ({authStore.getRoleName()})
                  </Text>
                )}
              </HStack>

              <Text>
                {authStore.user.email || "You haven't connected your email yet"}
              </Text>
            </VStack>
          </HStack>
        </Pressable>
      ) : (
        <ButtonLogin />
      )}
    </Box>
  );
});

const ListPool = observer(() => {
  const poolStore = useLocalObservable(() => new PoolStore());
  const isFocused = useIsFocused();

  useEffect(() => {
    if (isFocused) {
      poolStore.fetchPools();
    }
  }, [isFocused]);

  return (
    <>
      {poolStore.loading.fetchPools ? (
        <Box
          alignItems={'center'}
          top="50%"
          height="100%"
          style={{
            transform: [{translateY: -50}],
          }}>
          <Spinner size="lg" />
        </Box>
      ) : (
        <FlatList
          mt={2}
          data={poolStore.pools}
          renderItem={({item}) => <PoolItem pool={item} />}
          keyExtractor={item => BigNumber.from(item[0]).toNumber().toString()}
        />
      )}
    </>
  );
});

const PoolItem = observer(({pool}: {pool: never}) => {
  const id = BigNumber.from(pool[0]).toNumber();
  const name = pool[1];
  // const description = pool[2];
  const createdAt = BigNumber.from(pool[3]).toNumber();
  const closedAt = BigNumber.from(pool[4]).toNumber();
  const totalVotes = BigNumber.from(pool[5]).toNumber();
  const createdBy = pool[6];

  const navigation = useNavigation<any>();
  return (
    <Pressable
      onPress={() => {
        navigation.navigate('PoolDetail', {poolId: id});
      }}>
      <VStack
        px={3}
        py={2}
        justifyContent="flex-start"
        borderRadius={2}
        bgColor="rgba(11, 135, 147,0.1)"
        my={1}>
        <HStack display="flex">
          <HStack space={1} flexGrow={1}>
            <Text fontSize={16} fontWeight={600}>
              {name}
            </Text>
            <Text fontSize={16} fontWeight={500} color="gray.500">
              {`#${id}`}
            </Text>
          </HStack>

          <HStack space={1} alignItems="center">
            <Icon name="caret-up-outline" size={20} color="green" />
            <Text fontSize={16} fontWeight={500} color={'green.700'}>
              {totalVotes}
            </Text>
          </HStack>
        </HStack>

        <VStack>
          <Text fontSize={12} fontWeight={500} color="gray.600">
            {`Start: ${dayjs(createdAt * 1000).format('DD/MM/YYYY HH:mm')}`}
          </Text>

          <Text fontSize={12} fontWeight={500} color="gray.600">
            {`Close: ${dayjs(closedAt * 1000).format('DD/MM/YYYY HH:mm')}`}
          </Text>
        </VStack>

        <HStack justifyContent={'space-between'} alignItems="center">
          <Text fontSize={12} fontWeight={500} color="gray.600">
            {`Created by: ${Common.shortenAddress(createdBy)}`}
          </Text>
          <Badge
            variant="solid"
            colorScheme={closedAt > Date.now() / 1000 ? 'info' : 'red'}>
            {closedAt > Date.now() / 1000 ? 'Open' : 'Closed'}
          </Badge>
        </HStack>
      </VStack>
    </Pressable>
  );
});

export default HomeScreen;
