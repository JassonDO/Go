import {BigNumber} from 'ethers';

export type AndroidMode = 'date' | 'time';

export type PoolCreationData = {
  name: string;
  description: string;
  candidates: string[];
  endTime: Date;
};

export interface Pool {
  id: BigNumber;
  name: string;
  description: string;
  createdAt: BigNumber;
  closedAt: BigNumber;
  totalVotes: BigNumber;
  createdBy: string;
  candidates: Candidate[];
}

export interface Candidate {
  id: BigNumber;
  name: string;
  votes: BigNumber;
  voters: string[];
}

export interface Vote {
  _id: string;
  pool_id: number;
  candidate_id: number;
  name: string;
  voter: string;
  timestamp: number;
  pool: PoolDB;
}

export interface PoolDB {
  _id: string;
  pool_id: number;
  name: string;
  description: string;
  closed_at: number;
  timestamp: number;
}

export interface CandidateDB {
  _id: string;
  pool_id: number;
  name: string;
  candidate_id: number;
  vote_count: number;
}
