class Common {
  static shortenAddress(address: string): string {
    // get first 5 and last 5 characters of address
    return (
      address.substring(0, 10) + '...' + address.substring(address.length - 10)
    );
  }
}
export default Common;
