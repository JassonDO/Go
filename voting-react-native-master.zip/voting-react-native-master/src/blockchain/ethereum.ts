import MetaMaskSDK from '@metamask/sdk';
import _BackgroundTimer from 'react-native-background-timer';
import {Linking} from 'react-native';

const MMSDK = new MetaMaskSDK({
  openDeeplink: link => {
    Linking.openURL(link);
  },
  timer: _BackgroundTimer,
  dappMetadata: {
    name: 'Voting',
    url: 'https://voting.app',
  },
});

const ethereum = MMSDK.getProvider();

export default ethereum;
