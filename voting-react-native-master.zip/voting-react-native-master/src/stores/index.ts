import {makeAutoObservable} from 'mobx';
import {createContext, useContext} from 'react';
import AuthStore from './auth';
import UIStore from './ui';

export class RootStore {
  authStore: AuthStore;
  uiStore: UIStore;
  constructor() {
    makeAutoObservable(this);
    this.authStore = new AuthStore();
    this.uiStore = new UIStore();
  }
}

export const rootStore = new RootStore();

const rootContext = createContext<RootStore>(rootStore);

export const RootStoreProvider = rootContext.Provider;

export const useGlobalStore = () => {
  const store = useContext(rootContext);
  if (!store) {
    throw new Error('Store cannot be null, please add a context provider');
  }
  return store;
};
