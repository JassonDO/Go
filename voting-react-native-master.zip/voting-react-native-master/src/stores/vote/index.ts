import {action, makeAutoObservable, observable, runInAction} from 'mobx';
import VoteAPI from '../../apis/vote.api';
import {Vote} from '../../common/type';

export default class VoteStore {
  constructor() {
    makeAutoObservable(this);
  }

  @observable
  loading = {
    fetchVotes: false,
  };

  @observable
  errMessage = '';

  @observable
  votes = [] as Vote[];

  @action
  fetchVotes = async (address: string) => {
    this.loading.fetchVotes = true;
    this.errMessage = '';

    try {
      const votes = await VoteAPI.getVotesHistory(address);
      runInAction(() => {
        this.votes = votes || [];
      });
    } catch (err) {
    } finally {
      runInAction(() => {
        this.loading.fetchVotes = false;
      });
    }
  };
}
