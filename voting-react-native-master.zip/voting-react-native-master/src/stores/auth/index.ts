import {ethers} from 'ethers';
import {
  action,
  computed,
  makeAutoObservable,
  observable,
  runInAction,
} from 'mobx';
import {VOTING_ABI, VOTING_ABI_ADDRESS} from '../../../config';
import UserAPI from '../../apis/user.api';
import ethereum from '../../blockchain/ethereum';
export interface IUser {
  address: string;
  name: string;
  email: string;
}
export default class AuthStore {
  @observable
  loading = {
    connectWallet: false,
    getRole: false,
    getUser: false,
    updateUser: false,
  };

  @observable
  errMessage = '';

  @observable
  user = {} as IUser;

  @observable
  address = '';

  @computed
  isAdmin = () => {
    return this.role === 2;
  };

  @computed
  isModerator = () => {
    return this.role === 1;
  };

  @computed
  getRoleName = () => {
    switch (this.role) {
      case 0:
        return 'USER';
      case 1:
        return 'MODERATOR';
      case 2:
        return 'ADMIN';
      default:
    }
  };

  @observable
  role = 0;

  constructor() {
    makeAutoObservable(this);
  }

  @computed
  get isLoggedIn() {
    return this.address;
  }

  @action
  connectWallet = async () => {
    this.loading.connectWallet = true;
    this.errMessage = '';
    this.address = '';

    try {
      const accounts = await ethereum.request({method: 'eth_requestAccounts'});
      runInAction(() => {
        this.address = accounts[0];
      });

      this.getRole();
      this.getUser(this.address);
    } catch (err) {
      console.log(err);
    } finally {
      runInAction(() => {
        this.loading.connectWallet = false;
      });
    }
  };

  @action
  getRole = async () => {
    this.loading.getRole = true;

    try {
      const provider = new ethers.providers.Web3Provider(ethereum);
      const signer = provider.getSigner();
      const contract = new ethers.Contract(
        VOTING_ABI_ADDRESS,
        VOTING_ABI,
        signer,
      );
      const role = await contract.getRole(this.address);
      console.log('role', role);
      runInAction(() => {
        this.role = role.toNumber();
      });
    } catch (err) {
      console.log(err);
    } finally {
      runInAction(() => {
        this.loading.getRole = false;
      });
    }
  };

  @action
  getUser = async (address: string) => {
    this.loading.getUser = true;
    try {
      const response = await UserAPI.getUser(address);
      runInAction(() => {
        this.user = response;
      });
    } catch (err) {
      console.log(err);
    }
    runInAction(() => {
      this.loading.getUser = false;
    });
  };

  @action
  updateUser = async (data: {name: string; email: string}) => {
    this.loading.updateUser = true;
    try {
      const response = await UserAPI.updateUser(this.address, data);
      runInAction(() => {
        this.user = response;
      });
    } catch (err) {
      console.log(err);
    } finally {
      runInAction(() => {
        this.loading.updateUser = false;
      });
    }
  };

  @action
  logout = () => {
    this.address = '';
    this.user = {} as IUser;
    this.role = 0;
  };
}
