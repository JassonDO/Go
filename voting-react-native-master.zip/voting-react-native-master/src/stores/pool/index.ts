import dayjs from 'dayjs';
import {BigNumber, ethers} from 'ethers';
import {
  action,
  computed,
  makeAutoObservable,
  observable,
  runInAction,
} from 'mobx';
import {RPC_URL, VOTING_ABI, VOTING_ABI_ADDRESS} from '../../../config';
import PoolAPI from '../../apis/pool.api';
import VoteAPI from '../../apis/vote.api';
import ethereum from '../../blockchain/ethereum';
import {CandidateDB, Pool, PoolCreationData} from '../../common/type';

export default class PoolStore {
  @observable
  loading = {
    fetchPools: false,
    getPool: false,
    createPool: false,
    getIsVoted: false,
    vote: false,
    getWinner: false,
  };

  @observable
  errMessage = '';

  @observable
  pools = [];

  @observable
  pool: Pool | null = null;

  @observable
  isVoted = false;

  @observable
  candidate: string = '';

  @observable
  winners: CandidateDB[] = [];

  contract: ethers.Contract;

  constructor() {
    makeAutoObservable(this);
    this.contract = new ethers.Contract(
      VOTING_ABI_ADDRESS,
      VOTING_ABI,
      new ethers.providers.JsonRpcProvider(RPC_URL),
    );
  }

  @computed
  isClosed = () => {
    if (!this.pool) {
      return false;
    }
    return this.pool.closedAt.toNumber() < dayjs().unix();
  };

  @action
  fetchPools = async () => {
    this.loading.fetchPools = true;
    this.errMessage = '';
    this.pools = [];
    try {
      const pools = await this.contract.getPoolList();

      runInAction(() => {
        this.pools = pools;
      });
    } catch (err) {
    } finally {
      runInAction(() => {
        this.loading.fetchPools = false;
      });
    }
  };

  @action
  getPool = async (poolId: BigNumber) => {
    this.loading.getPool = true;
    this.errMessage = '';

    try {
      const [pool, candidates] = await Promise.all([
        this.contract.getPool(poolId),
        this.contract.getCandidates(poolId),
      ]);

      const poolData = {
        id: pool[0],
        name: pool[1],
        description: pool[2],
        createdAt: pool[3],
        closedAt: pool[4],
        totalVotes: pool[5],
        createdBy: pool[6],
        candidates: candidates.map((candidate: any) => ({
          id: candidate[0],
          name: candidate[1],
          votes: candidate[2],
          voters: candidate[3],
        })),
      };

      runInAction(() => {
        this.pool = poolData;
      });

      if (this.isClosed()) {
        const winner = await PoolAPI.getWinner(+poolId);
        runInAction(() => {
          this.winners = winner;
        });
      }
    } catch (err) {
    } finally {
      runInAction(() => {
        this.loading.getPool = false;
      });
    }
  };

  @action
  getIsVoted = async (poolId: BigNumber, address: string) => {
    this.loading.getIsVoted = true;
    this.errMessage = '';
    this.isVoted = false;

    try {
      const isVoted = await this.contract.isVoted(poolId, address);
      if (isVoted) {
        const vote = await VoteAPI.getVoteHistory(address, +poolId).catch(err =>
          console.log(err),
        );

        runInAction(() => {
          this.candidate = vote.name;
        });
      }

      runInAction(() => {
        this.isVoted = isVoted;
        console.log({isVoted: this.isVoted});
      });
    } catch (error) {
      console.log(error);
    } finally {
      runInAction(() => {
        this.loading.getIsVoted = false;
      });
    }
  };

  @action
  createPool = async (data: PoolCreationData) => {
    this.loading.createPool = true;
    this.errMessage = '';

    const provider = new ethers.providers.Web3Provider(ethereum);
    const signer = provider.getSigner();

    const writeContract = new ethers.Contract(
      VOTING_ABI_ADDRESS,
      VOTING_ABI,
      signer,
    );

    try {
      const tx = await writeContract.createPool(
        data.name,
        data.description,
        data.candidates,
        dayjs(data.endTime).unix(),
      );

      await tx.wait();
    } catch (err) {
      console.log(err);
    } finally {
      runInAction(() => {
        this.loading.createPool = false;
      });
    }
  };

  @action
  vote = async (poolId: BigNumber, candidateId: BigNumber) => {
    this.loading.vote = true;
    this.errMessage = '';

    const provider = new ethers.providers.Web3Provider(ethereum);
    const signer = provider.getSigner();

    const writeContract = new ethers.Contract(
      VOTING_ABI_ADDRESS,
      VOTING_ABI,
      signer,
    );

    try {
      const tx = await writeContract.vote(poolId, candidateId);

      await tx.wait();
    } catch (err) {
      console.log(err);
    } finally {
      runInAction(() => {
        this.loading.vote = false;
      });
    }
  };

  @action
  getWinner = async (poolId: BigNumber) => {
    this.loading.getWinner = true;
    this.errMessage = '';

    try {
      const winner = await PoolAPI.getWinner(poolId.toNumber());

      runInAction(() => {
        this.candidate = winner;
      });
    } catch (err) {
      console.log(err);
    } finally {
      runInAction(() => {
        this.loading.getWinner = false;
      });
    }
  };
}
