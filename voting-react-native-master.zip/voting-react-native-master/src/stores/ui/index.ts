import {action, computed, makeAutoObservable, observable} from 'mobx';
export interface IUser {
  address: string;
  name: string;
  email: string;
}
export default class UIStore {
  @observable
  loading = {};

  @observable
  currentScreen = '';

  constructor() {
    makeAutoObservable(this);
  }

  @computed
  getHeaderTitle() {
    const headerTitleMap: {[key: string]: string} = {
      VoteScreen: 'Vote History',
      PoolDetail: 'Pool Detail',
      AccountDetail: 'Account Detail',
      AccountUpdate: 'Account Update',
    };

    return headerTitleMap[this.currentScreen];
  }

  @action
  setCurrentScreen = (screen: string) => {
    this.currentScreen = screen;
  };
}
