import {DrawerActions, useNavigation} from '@react-navigation/native';
import {Box, HStack, IconButton, Image} from 'native-base';
import React from 'react';
import Icon from 'react-native-vector-icons/Ionicons';
const Header = () => {
  const navigation = useNavigation();

  return (
    <HStack justifyContent={'center'} bgColor="white">
      <IconButton
        onPress={() => {
          navigation.dispatch(DrawerActions.toggleDrawer());
        }}
        top={0}
        left={0}
        position="absolute"
        icon={<Icon name="menu" size={30} color="#360033" />}
        _pressed={{
          backgroundColor: 'transparent',
        }}
      />
      <Box>
        <Image
          w={120}
          h={60}
          source={require('../../assets/logo.png')}
          alt="logo"
        />
      </Box>
    </HStack>
  );
};

export default Header;
