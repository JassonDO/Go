import {observer} from 'mobx-react-lite';
import {HStack, Image, Pressable, Text} from 'native-base';
import React from 'react';
import {useGlobalStore} from '../../stores';

const ButtonLogin = observer(() => {
  const {authStore} = useGlobalStore();
  const connect = async () => {
    await authStore.connectWallet();
  };
  return (
    <Pressable
      onPress={connect}
      px={3}
      py={2}
      bgColor="rgba(232, 129, 30,0.5)"
      alignItems="center"
      justifyContent="center"
      borderRadius={2}>
      <HStack space={2} alignItems="center">
        <Image
          alt="metamask"
          source={require('../../assets/metamask.png')}
          size={50}
        />

        <Text fontSize={20} fontWeight={700} color="white">
          Login / Sign up
        </Text>
      </HStack>
    </Pressable>
  );
});

export default ButtonLogin;
