import axiosInstance from '.';

export default class PoolAPI {
  static async getWinner(poolId: number) {
    const response = await axiosInstance.get(`/pool/${poolId}/winner`);
    return response.data;
  }
}
