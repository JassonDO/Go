import axiosInstance from '.';

export default class UserAPI {
  static async getUser(address: string) {
    const response = await axiosInstance.get(`/user/${address}`);
    return response.data;
  }

  static async updateUser(
    address: string,
    data: {
      name: string;
      email: string;
    },
  ) {
    const response = await axiosInstance.put(`/user/${address}`, data);
    return response.data;
  }
}
