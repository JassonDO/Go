import axiosInstance from '.';

export default class VoteAPI {
  static async getVotesHistory(address: string) {
    const response = await axiosInstance.get(`/vote/${address}/histories`);
    return response.data;
  }

  static async getVoteHistory(address: string, poolId: number) {
    const response = await axiosInstance.get(`/vote/${address}/${poolId}`);
    return response.data;
  }
}
