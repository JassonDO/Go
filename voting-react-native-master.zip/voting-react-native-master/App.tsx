/**
 * Sample React Native App
 * https://github.com/facebook/react-native
 *
 * @format
 */

import React, {useEffect} from 'react';

import {createDrawerNavigator} from '@react-navigation/drawer';
import {NavigationContainer} from '@react-navigation/native';
import {extendTheme, NativeBaseProvider, StatusBar} from 'native-base';
import {Appearance} from 'react-native';
import SplashScreen from 'react-native-splash-screen';
import Icon from 'react-native-vector-icons/Ionicons';
import Header from './src/components/header';
import AccountStack from './src/screens/account/stack';
import HomeStack from './src/screens/home_screen/stack';
import VoteScreen from './src/screens/vote';
import {rootStore, RootStoreProvider} from './src/stores';
import {observer} from 'mobx-react-lite';
import PermissionScreen from './src/screens/permission/permission';
const theme = extendTheme({
  fontConfig: {
    Nunito: {
      100: {
        normal: 'Nunito-ExtraLight',
        italic: 'Nunito-EtraLightItalic',
      },
      200: {
        normal: 'Nunito-Light',
        italic: 'Nunito-LightItalic',
      },
      300: {
        normal: 'Nunito-Light',
        italic: 'Nunito-LightItalic',
      },
      400: {
        normal: 'Nunito-Regular',
        italic: 'Nunito-Italic',
      },
      500: {
        normal: 'Nunito-Medium',
        italic: 'Nunito-MediumItalic',
      },
      600: {
        normal: 'Nunito-SemiBold',
        italic: 'Nunito-SemiBoldItalic',
      },
      700: {
        normal: 'Nunito-Bold',
        italic: 'Nunito-BoldItalic',
      },
      800: {
        normal: 'Nunito-EtraBold',
        italic: 'Nunito-EtraBoldItalic',
      },
      900: {
        normal: 'Nunito-Black',
        italic: 'Nunito-BlackItalic',
      },
    },
  },

  fonts: {
    heading: 'Nunito',
    body: 'Nunito',
    mono: 'Nunito',
  },
});

function App(): JSX.Element {
  useEffect(() => {
    SplashScreen.hide();
  }, []);

  const colorScheme = Appearance.getColorScheme();

  return (
    <RootStoreProvider value={rootStore}>
      <NavigationContainer>
        <NativeBaseProvider theme={theme}>
          <StatusBar
            barStyle={colorScheme === 'dark' ? 'light-content' : 'dark-content'}
            backgroundColor={colorScheme === 'dark' ? '#000' : '#fff'}
          />
          <Navigation />
        </NativeBaseProvider>
      </NavigationContainer>
    </RootStoreProvider>
  );
}

const Drawer = createDrawerNavigator();

const Navigation = observer(() => {
  const {authStore} = rootStore;
  return (
    <Drawer.Navigator
      initialRouteName="HomeScreen"
      screenOptions={{
        header: () => Header(),
        drawerActiveBackgroundColor: 'rgba(126, 89, 236,0.2)',
        drawerActiveTintColor: '#7E59EC',
      }}>
      <Drawer.Screen
        name="HomeScreen"
        component={HomeStack}
        options={{
          drawerLabel: 'Home',
          drawerLabelStyle: {
            fontSize: 16,
            fontWeight: '600',
          },
          drawerIcon: ({focused}) => (
            <Icon name="home" size={30} color={focused ? '#7E59EC' : '#000'} />
          ),
        }}
      />

      <Drawer.Screen
        name="VoteScreen"
        component={VoteScreen}
        options={{
          drawerLabelStyle: {
            fontSize: 16,
            fontWeight: '600',
          },
          drawerLabel: 'Voting History',
          drawerIcon: ({focused}) => (
            <Icon
              name="newspaper-outline"
              size={30}
              color={focused ? '#7E59EC' : '#000'}
            />
          ),
        }}
      />

      {authStore.isAdmin() && (
        <Drawer.Screen
          name="PermissionScreen"
          component={PermissionScreen}
          options={{
            drawerLabelStyle: {
              fontSize: 16,
              fontWeight: '600',
            },
            drawerLabel: 'Permission',
            drawerIcon: ({focused}) => (
              <Icon
                name="key-outline"
                size={30}
                color={focused ? '#7E59EC' : '#000'}
              />
            ),
          }}
        />
      )}

      <Drawer.Screen
        name="AccountScreen"
        component={AccountStack}
        options={{
          drawerLabelStyle: {
            fontSize: 16,
            fontWeight: '600',
          },
          drawerLabel: 'Account',
          drawerIcon: ({focused}) => (
            <Icon
              name="person-outline"
              size={30}
              color={focused ? '#7E59EC' : '#000'}
            />
          ),
        }}
      />
    </Drawer.Navigator>
  );
});

export default App;
