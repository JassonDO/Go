module.exports = {
    assets: ['./fonts/'],
};
